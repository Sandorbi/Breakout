
import acm.graphics.*;

import acm.program.*;
import acm.util.*;
import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class Extensions extends GraphicsProgram {
	/** Width and height of application window in pixels */
	public static final int APPLICATION_WIDTH = 400;
	public static final int APPLICATION_HEIGHT = 600;

	/** Dimensions of game board (usually the same) */
	private static final int WIDTH = APPLICATION_WIDTH;
	private static final int HEIGHT = APPLICATION_HEIGHT;

	/** Dimensions of the paddle */
	private static final int PADDLE_WIDTH = 60;
	private static final int PADDLE_HEIGHT = 10;

	/** Offset of the paddle up from the bottom */
	private static final int PADDLE_Y_OFFSET = 30;

	/** Number of bricks per row */
	private static final int NBRICKS_PER_ROW = 10;

	/** Number of rows of bricks */
	private static final int NBRICK_ROWS = 10;

	/** Separation between bricks */
	private static final int BRICK_SEP = 4;

	/** Width of a brick */
	private static final int BRICK_WIDTH = (WIDTH - (NBRICKS_PER_ROW - 1) * BRICK_SEP) / NBRICKS_PER_ROW;

	/** Height of a brick */
	private static final int BRICK_HEIGHT = 8;

	/** Radius of the ball in pixels */
	private static final int BALL_RADIUS = 10;

	/** Offset of the top brick row from the top */
	private static final int BRICK_Y_OFFSET = 70;

	/** Number of turns */
	private static final int NTURNS = 3;

	// Delay of the ball movement.
	private static final int DELAY = 10;

	// Pause duration before the ball starts moving in milliseconds.
	private static final long GAME_START_PAUSE_DURATION = 3000;

	// Paddle instance variable.
	private GRect paddle;

	// Ball instance variable
	private GOval ball;

	private GRect brick;

	// private GLabel counterLabel;

	// velocity of the ball along x axis.
	private double vx;

	// velocity of the ball along y axis
	private double vy = 3;

	// Counter of Number of bricks broken.
	private int brickCounter;

	// Integer value for how many turns a player has left.
	private int turnsLeft = NTURNS - 1;

	// Boolean that becomes true if a player has no turn left.
	private boolean noTurnsLeft;

	// integer value of number of collisions
	// that occurred between paddle and the ball.
	private int paddleCollisionCounter;

	// Extension : Per 10 repels of ball by paddle, vx is doubled.

	public void run() {
		initiateGame();
		gameProcess();
	}

	// Creates bricks and paddle, which follows the cursor movement.
	private void initiateGame() {
		for (int i = 0; i < NBRICK_ROWS; i++) {
			for (int j = 0; j < NBRICKS_PER_ROW; j++) {
				createBrickRow(i, j);
			}
		}
		addPaddle();
		addMouseListeners();
	}

	// Creates row of bricks with given column and row numbers.
	private void createBrickRow(int columnNumber, int rowNumber) {
		brick = new GRect(BRICK_WIDTH, BRICK_HEIGHT);
		add(brick,
				(WIDTH - (NBRICKS_PER_ROW - 1) * BRICK_SEP - NBRICKS_PER_ROW * BRICK_WIDTH) / 2
						+ (BRICK_WIDTH + BRICK_SEP) * columnNumber,
				BRICK_Y_OFFSET + (BRICK_HEIGHT + BRICK_SEP) * rowNumber);
		brick.setFilled(true);
		setBrickColors(rowNumber, brick);
	}

	// Sets colors of bricks by rows.
	private void setBrickColors(int a, GObject rect) {
		int remainder = (a / 2) % 5;
		if (remainder == 0) {
			rect.setColor(Color.RED);
		}
		if (remainder == 1) {
			rect.setColor(Color.ORANGE);
		}
		if (remainder == 2) {
			rect.setColor(Color.YELLOW);
		}
		if (remainder == 3) {
			rect.setColor(Color.GREEN);
		}
		if (remainder == 4) {
			rect.setColor(Color.CYAN);
		}
	}

	// Adds paddle to the canvas at designated location.
	private void addPaddle() {
		paddle = new GRect(PADDLE_WIDTH, PADDLE_HEIGHT);
		paddle.setFilled(true);
		add(paddle, (WIDTH - PADDLE_WIDTH) / 2, HEIGHT - PADDLE_Y_OFFSET - PADDLE_HEIGHT);
	}

	// Moves paddle on canvas according to the cursor movement.
	public void mouseMoved(MouseEvent e) {
		double x = e.getX();
		if (x - PADDLE_WIDTH / 2 >= 0 && x + PADDLE_WIDTH / 2 <= WIDTH) {
			paddle.setLocation(x - PADDLE_WIDTH / 2, paddle.getY());
		}
	}

	// Starts the game. Creates the ball and starts its movement.
	private void gameProcess() {
		createBall();
		startBallMovement();
	}

	// Adds ball at the center of the canvas.
	private void createBall() {
		ball = new GOval(2 * BALL_RADIUS, 2 * BALL_RADIUS);
		add(ball, WIDTH / 2 - BALL_RADIUS, HEIGHT / 2 - BALL_RADIUS);
		ball.setFilled(true);
		pause(GAME_START_PAUSE_DURATION);
	}

	// Starts the movement of the ball. If every brick is broken it notifies
	// player that game is won.
	// If the player has reached the maximum number of attempts, shows
	// notification that the game is lost.
	private void startBallMovement() {
		setRandomXVelocity();
		while (true) {
			moveBall();
			checkCollisions();
			if (brickCounter == NBRICKS_PER_ROW * NBRICK_ROWS) {
				gameResult("You've Beaten the game!", Color.GREEN, 30);
				break;
			}
			if (noTurnsLeft == true) {
				gameResult("Game Over!", Color.RED, 30);
				break;
			}
		}
	}

	// randomly assigns values to velocity of the ball along the X axis.
	private void setRandomXVelocity() {
		RandomGenerator rgenx = RandomGenerator.getInstance();
		vx = rgenx.nextDouble(1.0, 3.0);
		if (rgenx.nextBoolean(0.5)) {
			vx = -vx;
		}
	}

	// Moves ball with given velocity.
	private void moveBall() {
		ball.move(vx, vy);
		pause(DELAY);
	}

	// Checks collisions with walls and objects.
	private void checkCollisions() {
		checkWallCollisions();
		checkObjectCollisions();
	}

	// Checks and repels if ball has collided with a wall.
	// And starts a new attempt if the ball has collided with bottom wall.
	private void checkWallCollisions() {
		if (ball.getX() + 2 * BALL_RADIUS > WIDTH || ball.getX() < 0) {
			vx = -vx;
		}

		if (ball.getY() < 0) {
			vy = -vy;
		}

		if (ball.getY() + 2 * BALL_RADIUS >= getHeight()) {
			if (turnsLeft > 0) {
				turnsLeft--;
				remove(ball);
				createBall();
				setRandomXVelocity();
			} else {
				noTurnsLeft = true;
			}
		}
	}

	// Checks and repels if the ball has collided with a brick or the paddle.
	private void checkObjectCollisions() {
		GObject collider = getCollidingObject();
		if (collider == paddle) {
			vy = -Math.abs(vy);
			paddleCollisionCounter++;
			if (paddleCollisionCounter % 10 == 0 & paddleCollisionCounter != 0) {
				vx = 2 * vx;
			}
		} else if (collider != null) {
			vy = -vy;
			remove(collider);
			brickCounter++;
		}
	}

	// Returns an Object the ball has collided with.
	private GObject getCollidingObject() {
		GObject topLObj = getElementAt(ball.getX(), ball.getY());
		GObject botRObj = getElementAt(ball.getX() + 2 * BALL_RADIUS, ball.getY() + 2 * BALL_RADIUS);
		GObject topRObj = getElementAt(ball.getX() + 2 * BALL_RADIUS, ball.getY());
		GObject botLObj = getElementAt(ball.getX(), ball.getY() + 2 * BALL_RADIUS);

		if (topLObj != null) {
			return (topLObj);
		}

		if (topRObj != null) {
			return (topRObj);
		}

		if (botLObj != null) {
			return (botLObj);
		}
		if (botRObj != null) {
			return (botRObj);
		}
		return (null);
	}

	// Adds notification label on canvas with given text.
	private void showNotificationLabel(String text, Color color, int fontSize) {
		GLabel notificationLabel = new GLabel(text);
		notificationLabel.setFont(new Font("Serif", Font.PLAIN, fontSize));
		notificationLabel.setColor(color);
		add(notificationLabel, getWidth() / 2 - notificationLabel.getWidth() / 2,
				getHeight() / 2 - notificationLabel.getAscent() / 2);
	}

	// Shows the game result to a player.
	private void gameResult(String text, Color color, int fontSize) {
		remove(ball);
		remove(paddle);
		showNotificationLabel(text, color, fontSize);
	}
}
